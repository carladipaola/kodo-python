import os
import sys
import random
import numpy
import kodo
import csv

# Configuration sender-helper1-relay-helper2-receiver

def DOF(g, e1, e2, e3):
    C = -1+e2+e3-e1*e3
    D = (2-e2-e3)*(1-e1)*e3
    r = -g*C/(D-C*(1-e3))
    return r

def simulation_run(g, symbol_size, e11, e21, e31, e12, e22, e32, eh, r1, k1):

    symbols = g
    # In the following we will make an encoder/decoder factory.
    # The factories are used to build actual encoders/decoders

    # encoder_factory = kodo.FullVectorEncoderFactoryBinary(symbols, symbol_size)
    encoder_factory = kodo.FullVectorEncoderFactoryBinary8(symbols, symbol_size)
    encoder = encoder_factory.build()

    # decoder_factory = kodo.FullVectorDecoderFactoryBinary(symbols, symbol_size)
    decoder_factory = kodo.FullVectorDecoderFactoryBinary8(symbols, symbol_size)
    decoder1 = decoder_factory.build()
    decoder2 = decoder_factory.build()
    decoder3 = decoder_factory.build()
    decoder4 = decoder_factory.build()       

    # Create some data to encode. 
    # In this case we make a buffer with the same size as the encoder's block size (the max. amount a single encoder can encode)
    # Fill the input data with random data

    data_in = os.urandom(encoder.block_size())

    # Assign the data buffer to the encoder so that we can produce encoded symbols

    encoder.set_symbols(data_in)

    # print("Transmission to R")
    packet_number_source = 0
    packet_number_helper1 = 0
    while not decoder3.is_complete():
        packet_number_source += 1
        # Broadcast transmission sender-helper1 & sender-relay

        # Generate an encoded packet
        packet_s = encoder.encode()
        # print("Packet {} encoded!".format(packet_number_source))

        # Send the data to the decoder3, here we simulate that we are loosing packets
        if random.random()>=e31:
		# Pass that packet to the decoder3
		decoder3.decode(packet_s)
		# print("Packet {} decoded (relay)!".format(packet_number_source))

        # Send the data to the decoder1, here we simulate that we are loosing packets
        if random.random()>=e11:
		# Pass that packet to the decoder1
		decoder1.decode(packet_s)
		# print("Packet {} decoded (helper1)!".format(packet_number_source))


        # Transmission helper1-relay 
        r1 = abs(DOF(g, e11, e21, e31))
        if decoder1.rank()>=r1:
                packet_number_helper1 += 1
		# Now produce a new recoded packet from the current decoding buffer, and place it into the payload buffer
		packet_h1 = decoder1.recode()
		# print("Packet {} recoded (helper1)!".format(packet_number_helper1))

        # Send the data to the decoder3, here we just for fun simulate that we are loosing packets
		if random.random()>=e21:
			# Pass that packet to the decoder3
			decoder3.decode(packet_h1)
			# print("Packet {} decoded (relay)!".format(packet_number_helper1))

        # Send the data to the decoder2, here we just for fun simulate that we are loosing packets
		if random.random()>=eh:
			# Pass that packet to the decoder2
			decoder2.decode(packet_h1)
			# print("Packet {} decoded (helper2)!".format(packet_number_helper1))

        # print("rank: {}/{}".format(decoder3.rank(), decoder3.symbols()))
    
    # print("Transmission to d")
    packet_number_relay = 0
    packet_number_helper2 = 0
    while not decoder4.is_complete():
        # print("rank helper2: {}".format(decoder2.rank())) 
        if decoder2.rank() < symbols:
		packet_number_relay += 1
		# Broadcast transmission relay-helper2 & relay-destination

		packet_r = decoder3.recode()
		# print("Packet {} recoded (relay)!".format(packet_number_relay))
	       
		# Send the data to the decoder4, here we simulate that we are loosing packets
		if random.random()>=e32:
			# Pass that packet to the decoder4
			decoder4.decode(packet_r)
			# print("Packet {} decoded (receiver)!".format(packet_number_relay))

		# Send the data to the decoder2, here we simulate that we are loosing packets
		if random.random()>=e12:
			# Pass that packet to the decoder2
			decoder2.decode(packet_r)
			# print("Packet {} decoded (helper2)!".format(packet_number_relay))

		# Transmission helper2-receiver 
		r2 = abs(DOF(g, e12, e22, e32))		       
		if decoder2.rank()>=r2:
		        packet_number_helper2 += 1
		        # print("Amount of packets sent by helper2: {}".format(packet_number_helper2))
			# Now produce a new recoded packet from the current decoding buffer, and place it into the payload buffer
			packet_h2 = decoder2.recode()
			# print("Packet {} recoded (helper2)!".format(packet_number_helper2))

		# Send the data to the decoder4, here we just for fun simulate that we are loosing packets
			if random.random()>=e22:
				# Pass that packet to the decoder4
				decoder4.decode(packet_h2)
				# print("Packet {} decoded (receiver)!".format(packet_number_helper2))

		# print("rank: {}/{}".format(decoder4.rank(), decoder4.symbols()))

        else:
		packet_number_helper2 += 1
	        # print("Amount of packets sent by helper2: {}".format(packet_number_helper2))
		# Now produce a new recoded packet from the current decoding buffer, and place it into the payload buffer
		packet_h2 = decoder2.recode()
		# print("Packet {} recoded (helper2)!".format(packet_number_helper2))

	# Send the data to the decoder4, here we just for fun simulate that we are loosing packets
		if random.random()>=e22:
			# Pass that packet to the decoder4
			decoder4.decode(packet_h2)
			# print("Packet {} decoded (receiver)!".format(packet_number_helper2))

	# print("rank: {}/{}".format(decoder4.rank(), decoder4.symbols()))
   

    #print("Processing finished")

    # print("r1 = {}".format(r1))
    # print("r2 = {}".format(r2))
    # print("Number of packets before helper2 starts transmitting = {}".format(r2-k1*(1-eh)))
    # print("Number of packets generated by the source = {}".format(packet_number_source))
    # print("Number of packets generated by the relay = {}".format(packet_number_relay))
    # print k1

    # The decoder4 is complete, now copy the symbols from the decoder4

    data_out4 = decoder4.copy_symbols()

    # Check if we properly decoded the data
    
    #print("Checking results")
    # if data_out4 == data_in:
        # print("Data decoded correctly")
    # else:
        # print("Unable to decode please file a bug report :)")
        # sys.exit(1)

    return [packet_number_source, packet_number_helper1, packet_number_helper2, packet_number_relay]

def main():
    # Set the number of symbols (i.e. the generation size in RLNC terminology) and the size of a symbol in bytes

    symbols = g = 64
    symbol_size = 160
    e11 = 0.2
    e21 = 0.5
    e31 = 0.8
    e12 = 0.2
    e22 = 0.5
    e32 = 0.8
    r1 = abs(DOF(g, e11, e21, e31))
    k1 = (g-r1*(1-e31))/(2-e21-e31)
    num_sim = 10000

    for eh in (0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1):
	    list_packet_source = [];
	    list_packet_helper1 = [];
	    list_packet_helper2 = [];
	    list_packet_relay = [];
	    for i in range(num_sim): 
		[packet_number_source, packet_number_helper1, packet_number_helper2, packet_number_relay] = simulation_run(g, symbol_size, e11, e21, e31, e12, e22, e32, eh, r1, k1)
		list_packet_source.append(packet_number_source)
		list_packet_helper1.append(packet_number_helper1)
		list_packet_helper2.append(packet_number_helper2)
		list_packet_relay.append(packet_number_relay)

	    # print("\nNumber packet source = {}".format(list_packet_source))
	    print("\nAverage source = {}".format(numpy.mean(list_packet_source)))
	    # print("\nNumber packet helper1 = {}".format(list_packet_helper1))
	    print("\nAverage helper1 = {}".format(numpy.mean(list_packet_helper1)))
	    # print("\nNumber packet helper2 = {}".format(list_packet_helper2))
	    print("\nAverage helper2 = {}".format(numpy.mean(list_packet_helper2))) 
	    # print("\nNumber packet relay = {}".format(list_packet_relay))
	    print("\nAverage relay = {}".format(numpy.mean(list_packet_relay)))
            print("\nTotal = {}".format(numpy.add(numpy.add(numpy.mean(list_packet_source),numpy.mean(list_packet_relay)), numpy.add(numpy.mean(list_packet_helper1), numpy.mean(list_packet_helper2)))))

	    data = {"eh": eh, "source": numpy.mean(list_packet_source), "helper1": numpy.mean(list_packet_helper1), "helper2": numpy.mean(list_packet_helper2), "relay": numpy.mean(list_packet_relay), "total": numpy.add(numpy.add(numpy.mean(list_packet_source),numpy.mean(list_packet_relay)), numpy.add(numpy.mean(list_packet_helper1), numpy.mean(list_packet_helper2)))}
	    print(data)

	    with open('PlayNCool_4_with_test.csv', 'a') as f:  
		    w = csv.DictWriter(f, data.keys())
		    #w.writeheader()
		    w.writerow(data) 

if __name__ == "__main__":
    main()
