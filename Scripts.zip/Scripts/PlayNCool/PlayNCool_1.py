import os
import sys
import random
import numpy
import kodo
import csv

# Basic configuration sender-helper-receiver

def DOF(g, e1, e2, e3):
    C = -1+e2+e3-e1*e3
    D = (2-e2-e3)*(1-e1)*e3
    r = -g*C/(D-C*(1-e3))
    return r

def simulation_run(g, symbol_size, e1, e2, e3):

    symbols = g
    # In the following we will make an encoder/decoder factory.
    # The factories are used to build actual encoders/decoders

    # encoder_factory = kodo.FullVectorEncoderFactoryBinary(symbols, symbol_size)
    encoder_factory = kodo.FullVectorEncoderFactoryBinary8(symbols, symbol_size)
    encoder = encoder_factory.build()

    # decoder_factory = kodo.FullVectorDecoderFactoryBinary(symbols, symbol_size)
    decoder_factory = kodo.FullVectorDecoderFactoryBinary8(symbols, symbol_size)
    decoder1 = decoder_factory.build()
    decoder2 = decoder_factory.build()

    assert(decoder1.rank()==0)
    assert(decoder2.rank()==0)
    # Create some data to encode. 
    # In this case we make a buffer with the same size as the encoder's block size (the max. amount a single encoder can encode)
    # Just for fun - fill the input data with random data

    data_in = os.urandom(encoder.block_size())

    # Assign the data buffer to the encoder so that we can produce encoded symbols

    encoder.set_symbols(data_in)

    # print("Processing")
    packet_number_source = 0
    packet_number_helper = 0
    while not decoder2.is_complete():
        packet_number_source += 1

        # Broadcast transmission sender-helper & sender-receiver

        # Generate an encoded packet
        packet_s = encoder.encode()
        # print("Packet {} encoded!".format(packet_number_source))

        # Send the data to the decoder2, here we simulate that we are loosing packets
        if random.random()>=e3:
		# Pass that packet to the decoder2
		decoder2.decode(packet_s)
		# print("Packet {} decoded (receiver)!".format(packet_number_source))

        # Send the data to the decoder1, here we simulate that we are loosing packets
        if random.random()>=e1:
		# Pass that packet to the decoder1
		decoder1.decode(packet_s)
		# print("Packet {} decoded (helper)!".format(packet_number_source))
    
		
        # Transmission helper-receiver
        r = abs(DOF(g, e1, e2, e3))
        if decoder1.rank()>=r:
                packet_number_helper += 1
		# Now produce a new recoded packet from the current decoding buffer, and place it into the payload buffer
		packet_h = decoder1.recode()
		# print("Packet {} recoded!".format(packet_number_helper))

        # Send the data to the decoder2, here we just for fun simulate that we are loosing packets
		if random.random()>=e2:
			# Pass that packet to the decoder2
			decoder2.decode(packet_h)
			# print("Packet {} decoded!".format(packet_number_helper))

        
        # print("rank: {}/{}".format(decoder2.rank(), decoder2.symbols()))

    # print("Processing finished")
    # print("r = {}".format(r))

    # The decoder2 is complete, now copy the symbols from the decoder2

    data_out2 = decoder2.copy_symbols()

    # Check if we properly decoded the data

    # print("Checking results")
    # if data_out2 == data_in:
        # print("Data decoded correctly")
    # else:
        # print("Unable to decode please file a bug report :)")
        # sys.exit(1)

    return [packet_number_source, packet_number_helper]

def main():
    # Set the number of symbols (i.e. the generation size in RLNC terminology) and the size of a symbol in bytes

    symbols = g = 64
    symbol_size = 160
    e1 = 0.2
    e3 = 0.8
    num_sim = 10000
    
    for e2 in (0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9):
            list_packet_source = [];
            list_packet_helper = [];
	    for i in range(num_sim): 
		[packet_number_source, packet_number_helper] = simulation_run(g, symbol_size, e1, e2, e3)
		list_packet_source.append(packet_number_source)
		list_packet_helper.append(packet_number_helper)

	    # print("\nNumber packet source = {}".format(list_packet_source))
	    print("\nAverage source = {}".format(numpy.mean(list_packet_source)))
	    # print("\nNumber packet helper = {}".format(list_packet_helper))
	    print("\nAverage helper = {}".format(numpy.mean(list_packet_helper)))
	    print("\nTotal = {}".format(numpy.add(numpy.mean(list_packet_source),numpy.mean(list_packet_helper))))

	    data = {"e2": e2, "source": numpy.mean(list_packet_source), "helper": numpy.mean(list_packet_helper), "total": numpy.add(numpy.mean(list_packet_source),numpy.mean(list_packet_helper))}
	    print(data)

	    with open('PlayNCool_1.csv', 'a') as f:  
		    w = csv.DictWriter(f, data.keys())
		    #w.writeheader()
		    w.writerow(data) 
		    
if __name__ == "__main__":
    main()
