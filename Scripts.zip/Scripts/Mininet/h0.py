import os
import sys
import random
import numpy
import kodo
import socket
import string
from struct import *

# UDP socket used to send packets to the switch s0 (the encoder) 
try:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
except socket.error, msg:
    print 'Failed to create socket.Error code: ' + str(msg[0]) + ' , Error message : ' + msg[1]
    sys.exit()
 
host = '10.0.0.2'  # IP address of h1
port = 8888

i = 0
j = 0
k = 0
x = 0
y = 0
z = 0
symbols = g = 64
symbol_size = 16

encoder_factory = kodo.FullVectorEncoderFactoryBinary8(symbols, symbol_size)
encoder = encoder_factory.build()

# Create some random data to send. 
# In this case we make a buffer with the same size as the encoder's block size (the max. amount a single encoder can encode)

data_in = os.urandom(encoder.block_size())
#data_in = ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(encoder.block_size()))  # data used to test the results
#print data_in
while i in range(0, len(data_in)):
    packet = data_in[i:i+symbol_size]
    #print packet 
    #print len(packet) # symbol_size
    
    try :
        #Set the packet
        s.sendto(packet, (host, port))
     
    except socket.error, msg:
        print 'Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
        sys.exit()

    i += symbol_size

print ('Sent {} packets'.format(i/symbol_size))

# receive an answer from h1
d = s.recvfrom(65565)
reply = d[0]
addr = d[1]         
#print reply
#print len(reply)


# Check if all the packets have been received by h1
while x in range(0, len(data_in)):
    for y in range(0, len(reply)):
        if (data_in[x:x+symbol_size] == reply[y:y+symbol_size]):
            z += 1
        y += symbol_size
    x += symbol_size    
print ('Number of packets received: {}'.format(z))


# Check if the packets have been received in the correct order by h1 
while j in range(0, len(data_in)):
    if (data_in[j:j+symbol_size] == reply[j:j+symbol_size]):
        k += 1
    j += symbol_size    
print ('Number of packets received in the correct order: {}'.format(k))
