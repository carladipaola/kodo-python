# RECEIVER

import os
import sys
import random
import numpy
import kodo
import socket
import struct
from struct import *

symbols = g = 64
symbol_size = 16
e1 = 0.2
e2 = 0.4
e3 = 0.6

packet_r = ''
packet_number = 0 
packet_number_source = 0
packet_number_helper = 0

decoder_factory = kodo.FullVectorDecoderFactoryBinary8(symbols, symbol_size)
decoder = decoder_factory.build()


#Convert a string of 6 characters of ethernet address into a dash separated hex string
def eth_addr (a):
  b = "%.2x:%.2x:%.2x:%.2x:%.2x:%.2x" % (ord(a[0]) , ord(a[1]) , ord(a[2]), ord(a[3]), ord(a[4]) , ord(a[5]))
  return b


# checksum function needed for calculation checksum
def function_checksum(msg):
    s = 0
     
    if len(msg) % 2 == 0:    
        # loop taking 2 characters at a time
        for i in range(0, len(msg), 2):
            w = ord(msg[i]) + (ord(msg[i+1]) << 8 )
            s = s + w

    else:
        for i in range(0, len(msg)-1, 2):
            w = ord(msg[i]) + (ord(msg[i+1]) << 8 )
            s = s + w

        w = ord(msg[len(msg)-1])
        s = s + w
     
    s = (s>>16) + (s & 0xffff);
    s = s + (s >> 16);
     
    #complement and mask to 4 byte short
    s = ~s & 0xffff
     
    return s
 

def dec_h_s(packet, packet_number):

    template_packet1 = ""
    template_packet2 = ""
    template_packet3 = ""
    
    #packet string from tuple
    packet = packet[0]
     
    #parse ethernet header
    eth_length = 14
     
    eth_header = packet[:eth_length]
    eth = unpack('!6s6sH', eth_header)
    eth_protocol = socket.ntohs(eth[2])
 
    #Parse IP packets, IP Protocol number = 8
    if eth_protocol == 8:
        #Parse IP header
        #take first 20 characters for the ip header
        ip_header = packet[eth_length:20+eth_length]
         
        #now unpack them :)
        iph = unpack('!BBHHHBBH4s4s', ip_header)
 
        version_ihl = iph[0]
        version = version_ihl >> 4
        ihl = version_ihl & 0xF
 
        iph_length = ihl * 4
 
        total_length = iph[2]
        ttl = iph[5]
        protocol = iph[6]
        s_addr = socket.inet_ntoa(iph[8]);
        d_addr = socket.inet_ntoa(iph[9]);

        if (s_addr == '10.0.0.1' and d_addr == '10.0.0.2'): 
        
            #print(total_length) # ip_header + ip_payload
            #UDP packets
            if protocol == 17:
                u = iph_length + eth_length
                udph_length = 8
                udp_header = packet[u:u+8]
     
                #now unpack them :)
                udph = unpack('!HHHH' , udp_header)
                 
                source_port = udph[0]
                dest_port = udph[1]
                length = udph[2]  # 8 + data_size
                checksum = udph[3]
                
                
                h_size = eth_length + iph_length + udph_length  # 14 + 20 + 8 = 42
                data_size = len(packet) - h_size
                #print data_size
                
                #get data from the packet
                data = packet[h_size:]
                if (len(data)==(symbol_size+5) or len(data)==(symbol_size+g+1)):
                    packet_number += 1
                
                    #print '\nSource MAC : ' + eth_addr(packet[6:12]) + ' Destination MAC : ' + eth_addr(packet[0:6]) + ' Protocol : ' + str(eth_protocol)
                    #print 'Source Address : ' + str(s_addr) + ' Destination Address : ' + str(d_addr) + ' Version : ' + str(version) + ' IP Header Length : ' + str(iph_length) + ' Protocol : ' + str(protocol) 
                    #print 'Source Port : ' + str(source_port) + ' Destination Port : ' + str(dest_port) + ' Length : ' + str(length) + ' Checksum : ' + str(checksum)
                    #print 'Data : ' + data

                    
                    template_packet1 = packet[0:eth_length+2]  # packet[eth_length+2:eth_length+4] = total length = IP datagram length (20) + UDP datagram length (8 + data length) changes according to the new data length
                    #print len(template_packet1) # 16
                    template_packet3 = packet[eth_length+4:-(len(data)+4)]  # packet[-(len(data)+4):] changes according to the new data length that affects both the length and the checksum
                    #print len(template_packet3)

                    #print('Packet received length: {}'.format(len(packet)))   


                    decoder.decode(data)
                    #print("rank: {}/{}".format(decoder.rank(), decoder.symbols()))

                    if decoder.is_complete():
                        packet_r_dec = decoder.copy_symbols()
                        #print ('\nDecoded packet: {}'.format(packet_r_dec))
                        #print("Decoded data length: {}\n".format(len(packet_r_dec)))
                         
                        # RAW socket used to send packets to the host h1
                        try:
                            s3 = socket.socket(socket.AF_PACKET, socket.SOCK_RAW)
                            s3.bind(("s2-eth3", 0))
                        except socket.error:
                            print 'Failed to create socket'
                            sys.exit()

                        i = 0
                        j = 0
                        while i in range(0, len(packet_r_dec)):
                            j += 1
                            packet_s2 = packet_r_dec[i:i+symbol_size]
                            #print packet_s2 
                            #print len(packet_s2) # symbol_size                          

                            length = 8 + len(packet_s2)  # udp_header_length + len(packet_s2)
                            #print length     
                            checksum = 0
                            length_checksum = pack('!HH', length, checksum)

                            template_packet2 = 20 + length  # IP datagram length + UDP datagram length

                            template_packet2 = pack('!H', template_packet2)
                            #print(len(template_packet2)) # 2
                            packet_s2 = template_packet1 + template_packet2 + template_packet3 + length_checksum + packet_s2 
                            #print("Packet decoded length: {}".format(len(packet_s2)))  # eth_header_length (14) + ip_header_length (20) + udp_header_length (8) + data_length

                            host = '10.0.0.2'
                            port = 8888

                            try :
                                #Set the packet
                                s3.send(packet_s2)
                             
                            except socket.error, msg:
                                print 'Error Code : ' + str(msg[0]) + ' Message: ' + msg[1]
                                sys.exit()     

                            #print ('Packet {} sent'.format(j))

                            i += symbol_size
                        print ('Sent {} packets'.format(j))

    return packet_number



#create a AF_PACKET type raw socket (thats basically packet level)
#define ETH_P_ALL    0x0003          /* Every packet (be careful!!!) */
# RAW socket used to receive packets from the switch s1 (the recoder)
try:
    s1 = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))
    s1.bind(("s2-eth1", 0))
except socket.error, msg:
    print 'Socket could not be created. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()

# RAW socket used to receive packets from the switch s0 (the encoder)
try:
    s2 = socket.socket(socket.AF_PACKET, socket.SOCK_RAW, socket.ntohs(0x0003))
    s2.bind(("s2-eth2", 0))
except socket.error, msg:
    print 'Socket could not be created. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()


while not decoder.is_complete():
 
    # receive a packet from the helper
    packet_h = s1.recvfrom(65565)
    packet_number_helper = dec_h_s(packet_h, packet_number_helper)

    if not decoder.is_complete():    

        # receive a packet from the source
        packet_s = s2.recvfrom(65565)
        packet_number_source = dec_h_s(packet_s, packet_number_source)

print 'Received {} packets from source'.format(packet_number_source)
print 'Received {} packets from helper'.format(packet_number_helper)
        