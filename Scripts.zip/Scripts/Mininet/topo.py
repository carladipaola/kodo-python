from mininet.net import Mininet
from mininet.node import RemoteController, OVSKernelSwitch
from mininet.link import TCLink
from mininet.cli import CLI

net = Mininet(controller=RemoteController, switch=OVSKernelSwitch, link=TCLink)

# Creating nodes in the network.
c0 = net.addController()
s0 = net.addSwitch('s0')
s1 = net.addSwitch('s1')
s2 = net.addSwitch('s2')
h0 = net.addHost('h0')
h1 = net.addHost('h1')

# Creating links between nodes in network
net.addLink(s0, s1, loss=20)
net.addLink(s1, s2, loss=40)
net.addLink(s0, s2, loss=60)
net.addLink(h0, s0, loss=0)
net.addLink(h1, s2, loss=0)

net.build()
net.start()
CLI(net)
net.stop()
