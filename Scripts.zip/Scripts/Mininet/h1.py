import socket
import sys 

HOST = '10.0.0.2'   
PORT = 8888 
i = 0
packet_h1 = ''

symbols = g = 64
symbol_size = 16

# UDP socket used to receive packets from the switch s2 (the decoder)
try :
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    print 'Socket created'
except socket.error, msg :
    print 'Failed to create socket. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()
 
 
# Bind socket to local host and port
try:
    s.bind((HOST, PORT))
except socket.error , msg:
    print 'Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()
     
print 'Socket bind complete'

print "waiting on port:", PORT
 
#now keep talking with the client
while i<symbols*2:
    
    # receive data from h0
    d = s.recvfrom(65565)
    data = d[0]
    addr = d[1]
    #print(len(addr[0])) # 8
    #print(len(str((addr[1])))) # 5
    
    if not data: 
        break
    
    #print 'Message[' + addr[0] + ':' + str(addr[1]) + '] - ' + data.strip()
    #print('Length: {}'.format(len(data)))
    if i >= symbols:  
        #print data.strip()
        packet_h1 = packet_h1 + data 
    i += 1
print ('Received {} packets'.format(i/2))

reply = packet_h1
s.sendto(reply, addr)    
s.close()